import { Component } from '@angular/core';
import { usersdata } from '../users.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class Logcomponent {
    public username:string="";
    public password:string="";
    public users:any;
    constructor(private _userservice:usersdata,private route:Router){

    }
    OnInit():void{

    }
    Register(){
       this.route.navigate(['register']);
    }

    Login(){
        this.users=this._userservice.GetUser();
        let flag=0;
        
        for(let i=0;i<this.users.length;i++){
            if(this.users[i].username==this.username && this.users[i].password==this.password){
                flag=1;
                alert("Login Sucessfull!");
                this.route.navigate(['blood']);
            }
        }
        if(flag==0){
            alert("Invalid username or password!");
        }
    }

    


  
}