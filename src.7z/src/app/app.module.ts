import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Logcomponent } from './login/login.component';
import { RouterModule } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { Bloodcomponent } from './blood/blood.component';
import { Historycomponent } from './history/history.component';


@NgModule({
  declarations: [
    AppComponent,
    Logcomponent,
    RegisterComponent,
    Bloodcomponent,
    Historycomponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot([
      {path:'',component:Logcomponent},
      {path:'register',component:RegisterComponent},
      {path:'blood',component:Bloodcomponent},
      {path:'history',component:Historycomponent}

    ])
  ],
  providers: [

  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
