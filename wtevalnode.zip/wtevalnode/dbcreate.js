 var mysql = require('mysql');
 /*

 var con = mysql.createConnection({
   host: "localhost",
  user: "root",
   password: ""
 
 });

con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");
  
   con.query("CREATE DATABASE nodelogin", function (err, result) 
   {
     if (err) throw err;
     console.log("Database created");
   });
 });

*/
 var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "nodelogin"
  });
  // //table accounts
/*
   con.connect(function(err) {
     if (err) throw err;
     console.log("Connected!");
    
     var sql = "CREATE TABLE studentlogin (username varchar(20),password varchar(20))";
     con.query(sql, function (err, result) {
       if (err) throw err;
       console.log("Table created");
     });
   });  */


/*
   con.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");
   
    var sql = "CREATE TABLE coursedetails (coursename varchar(20),coursecode varchar(20),coursefaculty varchar(20),videorating int)";
    con.query(sql, function (err, result) {
      if (err) throw err;
      console.log("Table created");
    });
  });

  con.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");
   
    var sql = "CREATE TABLE facultylogin (username varchar(20),password varchar(20))";
    con.query(sql, function (err, result) {
      if (err) throw err;
      console.log("Table created");
    });
  }); 
  con.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");
    var sql = "INSERT INTO studentlogin (username, password) VALUES ?";
    var values = [
      ['Atharv', 'atharv'],
      ['Adarsh','adarsh'],
      ['Mrunmay', 'mrunmay'],
      ['Akash', 'akash'],
      ['Bharati','bharati'],
      ['Joshua','joshua'],
      ['Raj','raj'],
      ['Alok','alok'],
      ['Varun','varun'],
      ['Kiran','kiran'],
      ['Kartik','kartik']
    ];
    con.query(sql, [values], function (err, result) {
      if (err) throw err;
      console.log("Number of records inserted: " + result.affectedRows);
    });
  });
  */

  con.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");
    var sql = "INSERT INTO facultylogin (username, password) VALUES ?";
    var values = [
      ['Atharv', 'atharv'],
      ['Adarsh','adarsh'],
      ['Mrunmay', 'mrunmay'],
      ['Akash', 'akash'],
      ['Bharati','bharati'],
      ['Joshua','joshua'],
      ['Raj','raj'],
      ['Alok','alok'],
      ['Varun','varun'],
      ['Kiran','kiran'],
      ['Kartik','kartik']
    ];
    con.query(sql, [values], function (err, result) {
      if (err) throw err;
      console.log("Number of records inserted: " + result.affectedRows);
    });
  });