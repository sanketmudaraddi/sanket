var mysql = require('mysql');
var express = require('express');
var app = express();
var session = require('express-session');
var bodyParser = require('body-parser');
var path = require('path');
var url=require('url');
const { response } = require('express');
const { request } = require('http');
var urlencodedParser=bodyParser.urlencoded({extended:true});

var con=mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'',
    database:'kindle'
})



app.use(session({
    secret: 'secret',
    resave: true,
    saveUninitialized: true
}));
   
   
app.use(bodyParser.urlencoded({extended : true}));
app.use(bodyParser.json());
   
app.get('/', function(request, response) {
    response.sendFile(path.join(__dirname + '/login.html'));
});


app.post('/validate', function(request, response) {
    var username = request.body.username;
    var password = request.body.password;
        if (username && password) {
     con.query('SELECT * FROM accounts1 WHERE username = ? AND password = ?', [username, password], function(error, results, fields) {
      if (results.length > 0) {
       request.session.loggedin = true;
       request.session.username = username;
       response.redirect('/home');
      } else {
       response.send('Incorrect Username and/or Password!');
      }   
      response.end();
     });
    }
    else {
     response.send('Please enter Username and Password!');
     response.end();
    }
});
   
   
app.get('/home', function(request, response) {
    if (request.session.loggedin) {
           if(request.session.username=="author")
           {
               response.redirect("/author");
           }
           else{
               response.redirect("/reader");
            }
    } else {
     response.send('Please login to view this page!');
    }
    response.end();
});

app.get('/reader', function (req, res) {
	var rr="<html>";
    res.write('<style>body{background-color: bisque;}</style>')
	rr = rr+"<body>";
	rr=rr+"<form  method='post' action='submission' >";
	rr = rr+"book name"+"<input type='text' name='bookname' value=' '> <br> <br>" ; 
	rr = rr+"author "+"<input type='text' name='author' value=' '> <br> <br>"; 
	rr = rr+"publication"+"<input type='text' name='publication' value=' '> <br> <br>";
	rr = rr+"book rating"+"<input type='number' name='rating' value=' '> <br> <br>";
	rr = rr+"<input type='submit' align='center' name='t1' value='Save '>";
	rr = rr+"</form>";
	rr = rr+"</body>";
	res.send(rr);
})

	app.post('/submission', urlencodedParser, function (req, res){
	  var reply='';
	  bname = req.body.bookname;
	  auth = req.body.author;
	  pub = req.body.publication;
	  rate = req.body.rating;
	  var sql =" insert into bookdetails(bookname,author,publication,rating) values('"+bname+"','"+auth+"','"+pub+"',"+rate+")";
	
	con.query(sql, function (err, result) {
		if (err) throw err; 
	  //res.end("Record inserted");
	  res.redirect('display');
	 });
	
	});

	app.get('/display', function (req, res) {
     
		con.query('select * from bookdetails ORDER BY rating DESC', function (err, result) {
		if (err) throw err;
		res.send(result)
		console.log(result)
	});
});

app.get('/author', function (req, res) {
	var rr="<html>";
    res.write('<style>body{background-color: bisque;}</style>')
	rr = rr+"<body>";
	rr=rr+"<form  method='post' action='getme' >";
	rr = rr+"book name"+"<input type='text' name='bookname' value=' '> <br> <br>" ; 
	rr = rr+"<input type='submit' align='center' name='t2' value='Submit '>";
	rr = rr+"</form>";
	rr = rr+"</body>";
	res.send(rr);
})

app.post('/getme', function (req, res) {
    cname = req.body.bookname
    con.query('select * from bookdetails where bookname = ?',[cname], function (err, result) {
    if (err) throw err;
    res.send(result)
    console.log(result)
});
});

app.listen(4010);