var mysql = require('mysql');
 
/*
var con = mysql.createConnection({
  host: "localhost",
 user: "root",
  password: ""

});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
 
  con.query("CREATE DATABASE kindle", function (err, result) 
  {
    if (err) throw err;
    console.log("Database created");
  });
});*/



var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "kindle"
});



con.connect(function(err) {
  if (err) throw err;
  console.log('Database is connected successfully !');
});

module.exports = con;
// //table accounts

/*
 con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");
  
   var sql = "CREATE TABLE accounts1 (username varchar(20),password varchar(20))";
   con.query(sql, function (err, result) {
     if (err) throw err;
     console.log("Table created");
   });
 });

 con.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");
    var sql = "INSERT INTO accounts1 (username, password) VALUES ?";
    var values = [
      ['author','author'],
      ['Pooja', 'pooja'],
      ['Laxmi','laxmi'],
      ['Namita', 'namita'],
      ['Akash', 'akash'],
      ['Bharati','bharati'],
      ['Joshua','joshua'],
      ['Raj','raj'],
      ['Alok','alok'],
      ['Varun','varun'],
      ['Kiran','kiran'],
      ['Kartik','kartik']
    ];
    con.query(sql, [values], function (err, result) {
      if (err) throw err;
      console.log("Number of records inserted: " + result.affectedRows);
    });
  });
  
  con.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");
   
    var sql = "CREATE TABLE bookdetails (bookname varchar(20),author varchar(20),publication varchar(20),rating int)";
    con.query(sql, function (err, result) {
      if (err) throw err;
      console.log("Table created");
    });
  });*/